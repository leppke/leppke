<?php
/**
 * Plugin Name: Stripe Riport
 * Description: A belső hálózaton futó Python script által feltöltött Stripe tranzakciós riport fogadása és megjelenítése a könyvelőnek. Használat: [stripe_riport] shortcode egy oldalon; a feltöltési token a Beállítások → Stripe Riport oldalon található.
 * Version: 1.3.0
 * Author: Festipay
 */

if (!defined('ABSPATH')) {
    exit;
}

const STRIPE_RIPORT_OPTION       = 'stripe_riport_data';
const STRIPE_RIPORT_TOKEN_OPTION = 'stripe_riport_token';
const STRIPE_RIPORT_CAP_READ     = 'stripe_riport_read';

/**
 * Aktiváláskor létrejön a "konyvelo" szerepkör (be tud lépni és látja a
 * riportot, mást nem szerkeszthet), az adminisztrátor megkapja az olvasási
 * jogot, és generálódik a feltöltési token, ha még nincs.
 */
register_activation_hook(__FILE__, function () {
    $admin = get_role('administrator');
    if ($admin) {
        $admin->add_cap(STRIPE_RIPORT_CAP_READ);
    }
    add_role('konyvelo', 'Könyvelő', ['read' => true, STRIPE_RIPORT_CAP_READ => true]);
    if (!get_option(STRIPE_RIPORT_TOKEN_OPTION)) {
        update_option(STRIPE_RIPORT_TOKEN_OPTION, wp_generate_password(48, false, false), false);
    }
});

/**
 * REST végpont: POST /wp-json/stripe-riport/v1/upload
 * Hitelesítés: X-Riport-Token fejléc, értéke a Beállítások → Stripe Riport
 * oldalon látható token. Szándékosan nem az Authorization fejlécet használjuk,
 * hogy JWT/egyéb hitelesítő bővítmények ne nyúljanak bele a kérésbe.
 * Törzs: {"rows": [{"date": "...", "id": "...", "amount": "...", "fee": "...",
 *                   "net": "...", "status": "...", "description": "..."}, ...]}
 */
add_action('rest_api_init', function () {
    register_rest_route('stripe-riport/v1', '/upload', [
        'methods'             => 'POST',
        'permission_callback' => function (WP_REST_Request $req) {
            $stored = (string) get_option(STRIPE_RIPORT_TOKEN_OPTION);
            $sent   = (string) $req->get_header('X-Riport-Token');
            return $stored !== '' && $sent !== '' && hash_equals($stored, $sent);
        },
        'callback'            => function (WP_REST_Request $req) {
            $body = $req->get_json_params();
            $rows = isset($body['rows']) && is_array($body['rows']) ? $body['rows'] : null;
            if ($rows === null) {
                return new WP_Error('bad_request', 'Hiányzó vagy hibás "rows" tömb.', ['status' => 400]);
            }

            $allowed_keys = STRIPE_RIPORT_ROW_KEYS;
            $clean = [];
            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $clean_row = [];
                foreach ($allowed_keys as $key) {
                    $clean_row[$key] = isset($row[$key]) ? sanitize_text_field((string) $row[$key]) : '';
                }
                $clean[] = $clean_row;
            }

            update_option(STRIPE_RIPORT_OPTION, [
                'updated' => current_time('mysql'),
                'rows'    => $clean,
            ], false);

            return ['ok' => true, 'count' => count($clean)];
        },
    ]);
});

/**
 * Beállítások → Stripe Riport: itt olvasható ki a feltöltési token, és itt
 * lehet újat generálni (a régi azonnal érvénytelenné válik).
 */
add_action('admin_menu', function () {
    add_options_page('Stripe Riport', 'Stripe Riport', 'manage_options', 'stripe-riport', function () {
        if (!current_user_can('manage_options')) {
            return;
        }
        if (isset($_POST['stripe_riport_regenerate'])) {
            check_admin_referer('stripe_riport_regenerate');
            update_option(STRIPE_RIPORT_TOKEN_OPTION, wp_generate_password(48, false, false), false);
            echo '<div class="notice notice-success"><p>Új token generálva — a Python konfigurációban is cserélni kell!</p></div>';
        }
        $token = (string) get_option(STRIPE_RIPORT_TOKEN_OPTION);
        if ($token === '') {
            $token = wp_generate_password(48, false, false);
            update_option(STRIPE_RIPORT_TOKEN_OPTION, $token, false);
        }
        ?>
        <div class="wrap">
            <h1>Stripe Riport</h1>
            <p>A belső gépen futó feltöltő script ezzel a tokennel hitelesít
               (a <code>WP_RIPORT_TOKEN</code> értéke a <code>.bat</code> fájlban):</p>
            <p><input type="text" readonly value="<?php echo esc_attr($token); ?>"
                      style="width: 100%; max-width: 600px; font-family: monospace;"
                      onclick="this.select();"></p>
            <form method="post">
                <?php wp_nonce_field('stripe_riport_regenerate'); ?>
                <p><button type="submit" name="stripe_riport_regenerate" value="1" class="button">
                    Új token generálása (a régi érvénytelenné válik)
                </button></p>
            </form>
        </div>
        <?php
    });
});

const STRIPE_RIPORT_CSV_HEADER = ['Dátum', 'Ügyfél', 'Azonosító', 'Összeg', 'Díj', 'Nettó', 'Státusz', 'Leírás'];
const STRIPE_RIPORT_ROW_KEYS   = ['date', 'customer', 'id', 'amount', 'fee', 'net', 'status', 'description'];

/**
 * CSV-export a könyvelőnek: admin-post.php?action=stripe_riport_export
 * Bejelentkezett, riport-olvasási jogú felhasználónak; UTF-8 BOM +
 * pontosvessző elválasztó, hogy a magyar Excel azonnal oszlopokra bontva
 * nyissa meg.
 */
add_action('admin_post_stripe_riport_export', function () {
    if (!current_user_can(STRIPE_RIPORT_CAP_READ)) {
        wp_die('Ez a riport csak jogosult felhasználóknak érhető el.', '', ['response' => 403]);
    }
    $data = get_option(STRIPE_RIPORT_OPTION);
    $rows = !empty($data['rows']) && is_array($data['rows']) ? $data['rows'] : [];

    nocache_headers();
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="stripe-riport-' . gmdate('Y-m-d') . '.csv"');

    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, STRIPE_RIPORT_CSV_HEADER, ';');
    foreach ($rows as $row) {
        $line = [];
        foreach (STRIPE_RIPORT_ROW_KEYS as $key) {
            $line[] = (string) ($row[$key] ?? '');
        }
        fputcsv($out, $line, ';');
    }
    fclose($out);
    exit;
});

/**
 * [stripe_riport] shortcode: táblázatban jeleníti meg a legutóbb feltöltött
 * riportot, Excel (CSV) letöltési gombbal. Csak bejelentkezett,
 * riport-olvasási joggal rendelkező felhasználó látja a tartalmat — maga az
 * oldal így akár publikus is lehet.
 */
add_shortcode('stripe_riport', function () {
    if (!is_user_logged_in() || !current_user_can(STRIPE_RIPORT_CAP_READ)) {
        return '<p>Ez a riport csak bejelentkezett, jogosult felhasználóknak érhető el.</p>';
    }

    $data = get_option(STRIPE_RIPORT_OPTION);
    if (empty($data['rows'])) {
        return '<p>Még nem érkezett riport.</p>';
    }

    $export_url = admin_url('admin-post.php?action=stripe_riport_export');

    // A .stripe-riport-bleed a sablon keskeny tartalomhasábjából kilépve
    // legfeljebb 1200px (vagy a képernyő 96%-a) szélességre engedi a táblázatot,
    // a hasáb közepére igazítva (negatív margóval, transform nélkül — a
    // transformos változat egyes sablonoknál oldalra csúszott).
    $out = '<style>
        .stripe-riport-bleed { width: min(96vw, 1200px);
            margin-left: calc((100% - min(96vw, 1200px)) / 2); }
        .stripe-riport-toolbar { display: flex; justify-content: space-between;
            align-items: center; gap: 12px; flex-wrap: wrap; margin: 0 0 10px; }
        .stripe-riport-toolbar p { margin: 0; }
        a.stripe-riport-export { display: inline-block; padding: 8px 16px;
            background: #2271b1; color: #fff; border-radius: 4px;
            text-decoration: none; font-weight: 600; }
        a.stripe-riport-export:hover { background: #135e96; color: #fff; }
        .stripe-riport-scroll { overflow-x: auto; }
        table.stripe-riport { width: 100%; border-collapse: collapse;
            font-size: 14px; line-height: 1.4; }
        table.stripe-riport th, table.stripe-riport td { padding: 8px 12px;
            border-bottom: 1px solid #ddd; text-align: left;
            white-space: nowrap; vertical-align: top; }
        table.stripe-riport thead th { background: #f0f0f1;
            border-bottom: 2px solid #c3c4c7; position: sticky; top: 0; }
        table.stripe-riport tbody tr:nth-child(even) { background: #f8f9fa; }
        table.stripe-riport tbody tr:hover { background: #eef4fa; }
        table.stripe-riport td:nth-child(3) { font-family: monospace;
            font-size: 12px; }
        table.stripe-riport th:nth-child(4), table.stripe-riport td:nth-child(4),
        table.stripe-riport th:nth-child(5), table.stripe-riport td:nth-child(5),
        table.stripe-riport th:nth-child(6), table.stripe-riport td:nth-child(6) {
            text-align: right; }
        table.stripe-riport td:nth-child(8) { white-space: normal;
            min-width: 220px; }
    </style>';

    $out .= '<div class="stripe-riport-bleed">';
    $out .= '<div class="stripe-riport-toolbar">'
          . '<p>Utolsó frissítés: ' . esc_html($data['updated'])
          . ' &nbsp;•&nbsp; ' . count($data['rows']) . ' tétel</p>'
          . '<a class="stripe-riport-export" href="' . esc_url($export_url) . '">'
          . 'Letöltés Excelbe (CSV)</a>'
          . '</div>';
    $out .= '<div class="stripe-riport-scroll">';
    $out .= '<table class="stripe-riport"><thead><tr>';
    foreach (STRIPE_RIPORT_CSV_HEADER as $col) {
        $out .= '<th>' . esc_html($col) . '</th>';
    }
    $out .= '</tr></thead><tbody>';
    foreach ($data['rows'] as $row) {
        $out .= '<tr>';
        foreach (STRIPE_RIPORT_ROW_KEYS as $key) {
            $out .= '<td>' . esc_html($row[$key] ?? '') . '</td>';
        }
        $out .= '</tr>';
    }
    $out .= '</tbody></table></div></div>';
    return $out;
});
